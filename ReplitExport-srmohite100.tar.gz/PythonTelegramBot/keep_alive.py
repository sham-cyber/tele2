import logging
import threading
import time
from flask import jsonify

logger = logging.getLogger(__name__)

def ping_server():
    """
    Function to periodically ping the server to keep it alive on Replit
    """
    # Import requests here to avoid circular imports
    import requests
    
    while True:
        try:
            # Get the Replit URL from environment - prefer REPLIT_DEV_DOMAIN if available
            if __import__('os').environ.get('REPLIT_DEV_DOMAIN'):
                replit_url = f"https://{__import__('os').environ.get('REPLIT_DEV_DOMAIN')}"
            else:
                replit_url = f"https://{__import__('os').environ.get('REPL_SLUG', 'telegram-bot')}.{__import__('os').environ.get('REPL_OWNER', 'repl')}.repl.co"
            
            # Ping the server
            response = requests.get(f"{replit_url}/ping")
            logger.debug(f"Ping status: {response.status_code}")
            
            # Wait 5 minutes before pinging again
            time.sleep(300)
        except Exception as e:
            logger.error(f"Error in ping_server: {e}")
            # Wait a minute before trying again
            time.sleep(60)

def keep_alive(app):
    """
    Set up keep-alive route and start background thread
    
    Args:
        app (Flask): Flask application to add route to
    """
    @app.route('/ping', methods=['GET'])
    def ping():
        """Route for ping requests to keep the server alive"""
        return jsonify({"status": "alive", "timestamp": time.time()}), 200
    
    # Start background thread for pinging the server
    ping_thread = threading.Thread(target=ping_server)
    ping_thread.daemon = True
    ping_thread.start()
    
    logger.info("Keep-alive service started")
