import os
import logging
import telebot
from telebot import types
from copy import copy
from database import get_or_create_user, log_message, get_config, set_config
from utils.ai_assistant import get_ai_response, generate_image_from_text
from utils.conversation_manager import add_message, get_conversation_context, clear_conversation
from utils.cloud_backup import backup_database_to_dropbox

logger = logging.getLogger(__name__)

def log_telegram_message(message, is_from_bot=False):
    """
    Helper function to log Telegram messages to database
    
    Args:
        message: Telegram message object
        is_from_bot: True if message is from bot, False if from user
    """
    try:
        # Get user or create if new
        user = None if is_from_bot else get_or_create_user(message.from_user)
        
        # Extract message details
        user_id = user.id if user else message.chat.id  # Use chat ID as fallback for bot messages
        chat_id = message.chat.id
        message_text = message.text
        message_id = message.message_id
        
        # Log to database
        log_message(
            user_id=user_id,
            chat_id=chat_id,
            message_text=message_text,
            telegram_message_id=message_id,
            is_from_user=not is_from_bot,
            is_from_bot=is_from_bot
        )
    except Exception as e:
        logger.error(f"Error logging message: {e}")

def initialize_bot():
    """
    Initialize and configure the Telegram bot instance
    
    Returns:
        telebot.TeleBot: Configured bot instance
    """
    # Get bot token from environment variable
    TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
    
    if not TOKEN:
        logger.error("No TELEGRAM_BOT_TOKEN found in environment variables")
        raise ValueError("TELEGRAM_BOT_TOKEN environment variable is not set")
    
    # Create bot instance
    bot = telebot.TeleBot(TOKEN)
    
    # Register handlers
    register_handlers(bot)
    
    return bot

def register_handlers(bot):
    """
    Register message handlers for the bot
    
    Args:
        bot (telebot.TeleBot): Bot instance to register handlers for
    """
    @bot.message_handler(commands=['start', 'help'])
    def handle_start_help(message):
        """Handler for /start and /help commands"""
        # Get user from database or create if new
        user = get_or_create_user(message.from_user)
        
        # Get welcome message from database
        if message.text.startswith('/start'):
            db_message = get_config('WELCOME_MESSAGE')
            if db_message:
                response = db_message
            else:
                response = (
                    "👋 Welcome to your AI-powered Telegram Bot!\n\n"
                    "I'm here to assist you with information, answer questions, and have conversations.\n\n"
                    "Send /help to see available commands."
                )
        else:  # /help
            db_message = get_config('HELP_MESSAGE')
            if db_message:
                response = db_message
            else:
                response = (
                    "Available commands:\n"
                    "/start - Start the bot\n"
                    "/help - Show this help message\n"
                    "/echo <text> - Echo back the provided text\n"
                    "/stats - Show your usage statistics\n"
                    "/image <prompt> - Generate an image based on your description\n"
                    "/reset - Reset our conversation history\n"
                    "/backup - Backup database to cloud storage (admin only)\n"
                    "/set_dropbox_token <token> - Set Dropbox token for backups (admin only)\n\n"
                    "Or just send me a message and I'll respond with AI-generated content!"
                )
        
        # Send the response
        sent_message = bot.send_message(message.chat.id, response)
        
        # Log the incoming and outgoing messages
        log_telegram_message(message)
        log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(commands=['echo'])
    def handle_echo_command(message):
        """Handler for /echo command"""
        # Extract the text after the command
        command_parts = message.text.split(' ', 1)
        if len(command_parts) > 1:
            echo_text = command_parts[1]
            sent_message = bot.reply_to(message, echo_text)
        else:
            sent_message = bot.reply_to(message, "Please provide some text to echo after the /echo command")
        
        # Log the incoming and outgoing messages
        log_telegram_message(message)
        log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(commands=['stats'])
    def handle_stats_command(message):
        """Handler for /stats command - shows user statistics"""
        from database import Session
        from models import User, Message
        
        session = Session()
        try:
            # Get the user
            user = session.query(User).filter_by(telegram_id=message.from_user.id).first()
            
            if not user:
                response = "You haven't interacted with the bot before. This is your first message!"
            else:
                # Get message counts
                total_messages = session.query(Message).filter_by(user_id=user.id).count()
                commands = session.query(Message).filter_by(user_id=user.id, is_command=True).count()
                
                # Format response
                response = (
                    f"📊 Your Statistics:\n\n"
                    f"👤 User: {user.first_name} {user.last_name if user.last_name else ''}\n"
                    f"🆔 Telegram ID: {user.telegram_id}\n"
                    f"📅 First interaction: {user.created_at.strftime('%Y-%m-%d %H:%M UTC')}\n"
                    f"📝 Total messages: {total_messages}\n"
                    f"🔢 Commands used: {commands}\n"
                )
        except Exception as e:
            logger.error(f"Error getting user stats: {e}")
            response = "Sorry, I couldn't retrieve your statistics right now. Please try again later."
        finally:
            session.close()
        
        # Send the response
        sent_message = bot.send_message(message.chat.id, response)
        
        # Log the incoming and outgoing messages
        log_telegram_message(message)
        log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(commands=['reset'])
    def handle_reset_command(message):
        """Handler for /reset command - clear conversation history"""
        # Clear user's conversation context
        clear_conversation(message.from_user.id)
        
        # Send confirmation
        sent_message = bot.send_message(message.chat.id, "🔄 Our conversation history has been reset. What would you like to talk about?")
        
        # Log the messages
        log_telegram_message(message)
        log_telegram_message(sent_message, is_from_bot=True)
        
    @bot.message_handler(commands=['backup'])
    def handle_backup_command(message):
        """Handler for /backup command - backup database to cloud storage"""
        # Check if user is admin
        user = get_or_create_user(message.from_user)
        
        if user is None or not getattr(user, 'is_admin', False):
            sent_message = bot.reply_to(message, "Sorry, only administrators can use this command.")
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
            return
            
        # Check if a Dropbox token is provided or stored
        dropbox_token = os.environ.get("DROPBOX_ACCESS_TOKEN")
        if not dropbox_token:
            dropbox_token = get_config("DROPBOX_ACCESS_TOKEN")
            
        if not dropbox_token:
            # No token available, provide instructions
            instructions = (
                "To backup the database to Dropbox, you need to set up a Dropbox access token.\n\n"
                "1. Go to https://www.dropbox.com/developers/apps\n"
                "2. Click 'Create app'\n"
                "3. Select 'Scoped access'\n"
                "4. Choose 'App folder'\n"
                "5. Name your app (e.g., 'TelegramBotBackup')\n"
                "6. Click 'Create app'\n"
                "7. Go to the 'Permissions' tab and select:\n"
                "   - files.content.write\n"
                "   - files.content.read\n"
                "8. Click 'Submit'\n"
                "9. Go back to the 'Settings' tab and click 'Generate' under 'Generated access token'\n"
                "10. Copy the token and send it to me in the format:\n"
                "/set_dropbox_token YOUR_TOKEN_HERE"
            )
            sent_message = bot.reply_to(message, instructions)
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
            return
            
        # Send processing message
        processing_message = bot.send_message(message.chat.id, "📦 Backing up the database... This may take a moment.")
        
        try:
            # Create backup and upload to Dropbox
            result = backup_database_to_dropbox(dropbox_token)
            
            if result["success"]:
                # Success message with the link
                success_message = (
                    f"✅ Database backup completed!\n\n"
                    f"Local backup: {result['local_backup']}\n"
                    f"Dropbox link: {result['dropbox_url']}\n\n"
                    f"The backup has been saved to your Dropbox account."
                )
                sent_message = bot.edit_message_text(
                    success_message,
                    chat_id=message.chat.id,
                    message_id=processing_message.message_id
                )
            else:
                # Error message
                error_message = f"❌ Backup failed: {result['error']}"
                sent_message = bot.edit_message_text(
                    error_message,
                    chat_id=message.chat.id,
                    message_id=processing_message.message_id
                )
                
            # Log the messages
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
            
        except Exception as e:
            logger.error(f"Error in backup command: {e}")
            error_message = f"❌ An error occurred during backup: {str(e)}"
            sent_message = bot.edit_message_text(
                error_message,
                chat_id=message.chat.id,
                message_id=processing_message.message_id
            )
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(commands=['set_dropbox_token'])
    def handle_set_dropbox_token(message):
        """Handler for /set_dropbox_token command - set Dropbox access token"""
        # Check if user is admin
        user = get_or_create_user(message.from_user)
        
        if user is None or not getattr(user, 'is_admin', False):
            sent_message = bot.reply_to(message, "Sorry, only administrators can use this command.")
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
            return
            
        # Extract the token
        command_parts = message.text.split(' ', 1)
        if len(command_parts) > 1:
            token = command_parts[1].strip()
            
            # Store the token in the database
            success = set_config("DROPBOX_ACCESS_TOKEN", token, "Dropbox access token for backups")
            
            if success:
                # Delete the message containing the token for security
                bot.delete_message(message.chat.id, message.message_id)
                
                # Send confirmation
                sent_message = bot.send_message(message.chat.id, "✅ Dropbox access token has been saved. You can now use the /backup command.")
            else:
                sent_message = bot.reply_to(message, "❌ Failed to save the Dropbox access token. Please try again.")
                
            # Create a copy of the message to log with redacted text
            redacted_message = copy(message)
            redacted_message.text = "/set_dropbox_token [TOKEN REDACTED]"
            
            # Log the messages
            log_telegram_message(redacted_message)
            log_telegram_message(sent_message, is_from_bot=True)
        else:
            sent_message = bot.reply_to(message, "Please provide the Dropbox access token after the command. For example: /set_dropbox_token YOUR_TOKEN_HERE")
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(commands=['image'])
    def handle_image_command(message):
        """Handler for /image command - generate an image using DALL-E"""
        # Extract the prompt after the command
        command_parts = message.text.split(' ', 1)
        if len(command_parts) > 1:
            prompt = command_parts[1]
            
            # Send "generating" message
            processing_message = bot.send_message(message.chat.id, "🖌️ Generating image based on your prompt... This may take a moment.")
            
            try:
                # Generate image
                image_url = generate_image_from_text(prompt)
                
                if image_url:
                    # Send the generated image
                    photo_message = bot.send_photo(message.chat.id, image_url, caption=f"Image generated based on: {prompt}")
                    bot.delete_message(message.chat.id, processing_message.message_id)
                    
                    # Log the messages
                    log_telegram_message(message)
                    log_telegram_message(photo_message, is_from_bot=True)
                else:
                    error_message = bot.edit_message_text("Sorry, I couldn't generate an image from that prompt. Please try a different description.", 
                                       chat_id=message.chat.id, 
                                       message_id=processing_message.message_id)
                    
                    # Log the messages
                    log_telegram_message(message)
                    log_telegram_message(error_message, is_from_bot=True)
            except Exception as e:
                logger.error(f"Error generating image: {e}")
                error_message = bot.edit_message_text("Sorry, there was an error generating the image. Please try again later.", 
                                   chat_id=message.chat.id, 
                                   message_id=processing_message.message_id)
                
                # Log the messages
                log_telegram_message(message)
                log_telegram_message(error_message, is_from_bot=True)
        else:
            sent_message = bot.reply_to(message, "Please provide a description after the /image command. For example: /image a cat wearing a space suit")
            
            # Log the messages
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
    
    @bot.message_handler(func=lambda message: True)
    def handle_all_messages(message):
        """Handler for all other messages - process with AI"""
        user_id = message.from_user.id
        user_message = message.text
        
        # Get user's conversation context
        context = get_conversation_context(user_id)
        
        # Send "typing" action
        bot.send_chat_action(message.chat.id, 'typing')
        
        try:
            # Add user message to conversation history
            add_message(user_id, "user", user_message)
            
            # Get AI response
            ai_response = get_ai_response(user_message, user_id, context)
            
            # Add AI response to conversation history
            add_message(user_id, "assistant", ai_response)
            
            # Send the response
            sent_message = bot.reply_to(message, ai_response)
            
            # Log the messages
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)
            
        except Exception as e:
            logger.error(f"Error processing message with AI: {e}")
            sent_message = bot.reply_to(message, "Sorry, I'm having trouble processing your message right now. Please try again later.")
            
            # Log the messages
            log_telegram_message(message)
            log_telegram_message(sent_message, is_from_bot=True)

def start_polling(bot):
    """
    Start the bot in polling mode
    
    Args:
        bot (telebot.TeleBot): Bot instance to start
    """
    logger.info("Starting bot in polling mode...")
    
    try:
        # Start polling
        bot.infinity_polling()
    except Exception as e:
        logger.error(f"Error in polling mode: {e}")
        raise

def process_webhook_update(bot, update_json):
    """
    Process webhook update from Telegram
    
    Args:
        bot (telebot.TeleBot): Bot instance
        update_json (dict): Update data from Telegram
    """
    try:
        # Parse the update
        update = types.Update.de_json(update_json)
        
        # Process the update
        bot.process_new_updates([update])
        
        # Note: Message logging is handled in the message handlers
        return True
    except Exception as e:
        logger.error(f"Error processing webhook update: {e}")
        return False
