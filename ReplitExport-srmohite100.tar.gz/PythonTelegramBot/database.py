import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from models import Base, User, Message, BotConfig

logger = logging.getLogger(__name__)

# Default database URL (SQLite) if no PostgreSQL URL is provided
DEFAULT_DB_URL = "sqlite:///bot_database.db"

def get_database_url():
    """
    Get the database URL from environment variables
    Falls back to SQLite if not found
    """
    db_url = os.environ.get("DATABASE_URL")
    
    if not db_url:
        logger.warning("DATABASE_URL not found in environment variables. Using SQLite as fallback.")
        return DEFAULT_DB_URL
    
    # Handle common PostgreSQL URL format issues
    if db_url.startswith("postgres://"):
        # Some systems use 'postgres://' but SQLAlchemy requires 'postgresql://'
        db_url = db_url.replace("postgres://", "postgresql://", 1)
    
    return db_url

# Initialize database connection
db_url = get_database_url()
engine = create_engine(db_url)

# Create a scoped session to ensure thread safety
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

def init_db():
    """
    Initialize the database by creating tables if they don't exist
    and adding initial configuration
    
    Returns:
        bool: True if initialization was successful, False otherwise
    """
    try:
        # Create all tables
        Base.metadata.create_all(engine)
        logger.info("Database tables created successfully")
        
        # Add default configuration if it doesn't exist
        session = Session()
        try:
            # Check if we have a webhook_url config already
            webhook_config = session.query(BotConfig).filter_by(name="webhook_url").first()
            if not webhook_config:
                # Add default configuration
                default_webhook = os.environ.get("WEBHOOK_URL", "")
                webhook_config = BotConfig(
                    name="webhook_url",
                    value=default_webhook,
                    description="URL for Telegram webhook"
                )
                session.add(webhook_config)
                
                # Add bot mode config
                bot_mode = os.environ.get("BOT_MODE", "polling")
                mode_config = BotConfig(
                    name="bot_mode",
                    value=bot_mode,
                    description="Bot operation mode: polling or webhook"
                )
                session.add(mode_config)
                
                # Add welcome and help messages
                welcome_msg = BotConfig(
                    name="WELCOME_MESSAGE",
                    value="👋 Welcome to your AI-powered Telegram Bot!\n\nI'm here to assist you with information, answer questions, and have conversations.\n\nSend /help to see available commands.",
                    description="Welcome message shown to new users"
                )
                session.add(welcome_msg)
                
                help_msg = BotConfig(
                    name="HELP_MESSAGE",
                    value="Available commands:\n/start - Start the bot\n/help - Show this help message\n/echo <text> - Echo back the provided text\n/stats - Show your usage statistics\n/image <prompt> - Generate an image based on your description\n/reset - Reset our conversation history\n\nOr just send me a message and I'll respond with AI-generated content!",
                    description="Help message shown to users"
                )
                session.add(help_msg)
                
                session.commit()
                logger.info("Default configuration created")
                
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Error creating default configuration: {e}")
            return False
        finally:
            session.close()
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        return False

def get_or_create_user(telegram_user):
    """
    Get a user from the database or create if not exists
    
    Args:
        telegram_user: User object from Telegram update
        
    Returns:
        User: Database user object
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_user.id).first()
        
        if not user:
            # Create new user
            user = User(
                telegram_id=telegram_user.id,
                username=getattr(telegram_user, 'username', None),
                first_name=getattr(telegram_user, 'first_name', None),
                last_name=getattr(telegram_user, 'last_name', None),
                language_code=getattr(telegram_user, 'language_code', None)
            )
            session.add(user)
            session.commit()
            logger.info(f"Created new user: {user.telegram_id}")
        
        return user
    except Exception as e:
        session.rollback()
        logger.error(f"Error getting or creating user: {e}")
        return None
    finally:
        session.close()

def log_message(user_id, chat_id, message_text, telegram_message_id=None, is_from_user=True, is_from_bot=None, is_command=False):
    """
    Log a message to the database
    
    Args:
        user_id: Database user ID
        chat_id: Telegram chat ID
        message_text: Text content of the message
        telegram_message_id: Original Telegram message ID (if available)
        is_from_user: True if message is from user, False if from bot
        is_from_bot: True if message is from bot, False if from user (if None, will be set as opposite of is_from_user)
        is_command: True if message is a command
        
    Returns:
        Message: Created message object or None on error
    """
    session = Session()
    try:
        # If is_from_bot is not provided, set it as the opposite of is_from_user
        if is_from_bot is None:
            is_from_bot = not is_from_user
            
        # Check if the message is a command (starts with /)
        if is_from_user and message_text and message_text.startswith('/'):
            is_command = True
            
        message = Message(
            user_id=user_id,
            chat_id=chat_id,
            message_text=message_text,
            telegram_message_id=telegram_message_id,
            is_from_user=is_from_user,
            is_from_bot=is_from_bot,
            is_command=is_command
        )
        session.add(message)
        session.commit()
        return message
    except Exception as e:
        session.rollback()
        logger.error(f"Error logging message: {e}")
        return None
    finally:
        session.close()

def get_config(name):
    """
    Get a configuration value from the database
    
    Args:
        name: Configuration name
        
    Returns:
        str: Configuration value or None if not found
    """
    session = Session()
    try:
        config = session.query(BotConfig).filter_by(name=name).first()
        return config.value if config else None
    except Exception as e:
        logger.error(f"Error getting config {name}: {e}")
        return None
    finally:
        session.close()

def set_config(name, value, description=None):
    """
    Set a configuration value in the database
    
    Args:
        name: Configuration name
        value: Configuration value
        description: Optional description
        
    Returns:
        bool: Success status
    """
    session = Session()
    try:
        config = session.query(BotConfig).filter_by(name=name).first()
        
        if config:
            # Update existing config
            config.value = value
            if description:
                config.description = description
        else:
            # Create new config
            config = BotConfig(
                name=name,
                value=value,
                description=description
            )
            session.add(config)
            
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Error setting config {name}: {e}")
        return False
    finally:
        session.close()