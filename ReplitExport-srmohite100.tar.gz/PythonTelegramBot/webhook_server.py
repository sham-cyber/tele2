import os
import logging
import datetime
from flask import Flask, request, render_template, jsonify, redirect, url_for
from bot import initialize_bot, process_webhook_update
from keep_alive import keep_alive
from database import Session
from models import User, Message, BotConfig

logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Global bot instance
bot = None

def initialize_webhook():
    """Initialize the webhook configuration for the bot"""
    global bot
    bot = initialize_bot()
    
    # Register the keep_alive route to prevent Replit from sleeping
    keep_alive(app)
    
    # Get webhook settings from environment
    WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "")
    if not WEBHOOK_URL:
        logger.warning("WEBHOOK_URL environment variable is not set")
    
    # Set webhook for the bot
    try:
        bot.remove_webhook()
        bot.set_webhook(url=WEBHOOK_URL)
        logger.info(f"Webhook set to {WEBHOOK_URL}")
    except Exception as e:
        logger.error(f"Failed to set webhook: {e}")
        
def initialize_webhook_app():
    """Legacy method for backward compatibility"""
    initialize_webhook()
    # Start Flask app
    app.run(host='0.0.0.0', port=5000)
    
@app.route('/', methods=['GET'])
def index():
    """Route for the home page"""
    bot_info = None
    try:
        if bot:
            bot_info = bot.get_me()
    except Exception as e:
        logger.error(f"Error getting bot info: {e}")
    
    # Get stats from database
    stats = get_bot_stats()
    
    return render_template('index.html', bot_info=bot_info, stats=stats)

@app.route('/users', methods=['GET'])
def users():
    """Route for the users page - shows all users who have interacted with the bot"""
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page
    
    session = Session()
    try:
        users = session.query(User).order_by(User.last_interaction.desc()).offset(offset).limit(per_page).all()
        total_users = session.query(User).count()
        
        return render_template('users.html', 
                              users=users, 
                              page=page, 
                              per_page=per_page, 
                              total_users=total_users, 
                              last_page=(total_users // per_page) + (1 if total_users % per_page else 0))
    except Exception as e:
        logger.error(f"Error retrieving users: {e}")
        return render_template('users.html', error=str(e), users=[])
    finally:
        session.close()

@app.route('/messages', methods=['GET'])
def messages():
    """Route for the messages page - shows recent messages"""
    page = request.args.get('page', 1, type=int)
    per_page = 50
    offset = (page - 1) * per_page
    
    user_id = request.args.get('user_id', None, type=int)
    
    session = Session()
    try:
        query = session.query(Message).order_by(Message.created_at.desc())
        
        if user_id:
            query = query.filter(Message.user_id == user_id)
            
        messages = query.offset(offset).limit(per_page).all()
        total_messages = query.count()
        
        users = {}
        for message in messages:
            if message.user_id not in users:
                user = session.query(User).filter_by(telegram_id=message.user_id).first()
                users[message.user_id] = user
                
        return render_template('messages.html', 
                              messages=messages, 
                              users=users,
                              page=page, 
                              per_page=per_page, 
                              total_messages=total_messages,
                              user_id=user_id,
                              last_page=(total_messages // per_page) + (1 if total_messages % per_page else 0))
    except Exception as e:
        logger.error(f"Error retrieving messages: {e}")
        return render_template('messages.html', error=str(e), messages=[])
    finally:
        session.close()

@app.route('/config', methods=['GET', 'POST'])
def config():
    """Route for the bot configuration page"""
    from database import set_config
    
    if request.method == 'POST':
        # Update configuration
        key = request.form.get('key')
        value = request.form.get('value')
        description = request.form.get('description')
        
        if key and value:
            set_config(key, value, description)
            return redirect(url_for('config', success=True))
    
    # Get all configuration settings
    session = Session()
    try:
        configs = session.query(BotConfig).order_by(BotConfig.key).all()
        return render_template('config.html', configs=configs, success=request.args.get('success'))
    except Exception as e:
        logger.error(f"Error retrieving config: {e}")
        return render_template('config.html', error=str(e), configs=[])
    finally:
        session.close()

@app.route('/logs', methods=['GET'])
def logs():
    """Route for viewing application logs"""
    import subprocess
    
    lines = request.args.get('lines', 100, type=int)
    
    try:
        # Get the most recent log entries
        output = subprocess.check_output(
            f"tail -n {lines} ~/.pm2/logs/main-out.log 2>/dev/null || echo 'No logs found'", 
            shell=True, 
            universal_newlines=True
        )
        
        log_entries = output.strip().split('\n')
        
        return render_template('logs.html', log_entries=log_entries, lines=lines)
    except Exception as e:
        logger.error(f"Error retrieving logs: {e}")
        return render_template('logs.html', error=str(e), log_entries=[])

@app.route('/webhook', methods=['POST'])
def webhook():
    """Route for handling Telegram webhook requests"""
    if not bot:
        return jsonify({"status": "error", "message": "Bot not initialized"}), 500
    
    try:
        update_json = request.get_json()
        
        if update_json:
            process_webhook_update(bot, update_json)
            return jsonify({"status": "success"}), 200
        else:
            return jsonify({"status": "error", "message": "Invalid update"}), 400
    except Exception as e:
        logger.error(f"Error processing webhook: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/status', methods=['GET'])
def status():
    """Route for checking bot status"""
    if not bot:
        return jsonify({"status": "error", "message": "Bot not initialized"}), 500
    
    try:
        bot_info = bot.get_me()
        stats = get_bot_stats()
        
        return jsonify({
            "status": "success",
            "bot_name": bot_info.first_name,
            "bot_username": bot_info.username,
            "bot_id": bot_info.id,
            "webhook_mode": bool(os.environ.get("WEBHOOK_URL", "")),
            "users_count": stats.get("users_count", 0),
            "messages_count": stats.get("messages_count", 0)
        }), 200
    except Exception as e:
        logger.error(f"Error getting bot status: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

def get_bot_stats():
    """Get bot statistics from the database"""
    session = Session()
    try:
        stats = {}
        
        # Get user count
        stats["users_count"] = session.query(User).count()
        
        # Get message count
        stats["messages_count"] = session.query(Message).count()
        
        # Get incoming/outgoing message counts
        stats["incoming_count"] = session.query(Message).filter_by(is_from_bot=False).count()
        stats["outgoing_count"] = session.query(Message).filter_by(is_from_bot=True).count()
        
        # Get command count
        stats["command_count"] = session.query(Message).filter_by(is_command=True).count()
        
        # Get active users (interacted in the last 24 hours)
        yesterday = datetime.datetime.utcnow() - datetime.timedelta(days=1)
        stats["active_users"] = session.query(User).filter(User.last_interaction >= yesterday).count()
        
        return stats
    except Exception as e:
        logger.error(f"Error getting bot stats: {e}")
        return {}
    finally:
        session.close()
