# This is the entry point for the Replit environment
import os
import logging
from load_env import get_env
from bot import initialize_bot, start_polling
from webhook_server import app, initialize_webhook
from database import init_db

# Configure logging
logging.basicConfig(level=logging.DEBUG, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables 
env = get_env()
logger.debug(f"Environment loaded. Bot mode: {env['BOT_MODE']}")

# Initialize database
logger.info("Initializing database...")
db_initialized = init_db()
if db_initialized:
    logger.info("Database initialized successfully")
else:
    logger.error("Failed to initialize database")

# Determine bot running mode from environment variable (polling is default)
BOT_MODE = env["BOT_MODE"].lower()

# Initialize bot for webhook mode
if BOT_MODE == "webhook":
    try:
        logger.info("Initializing webhook...")
        initialize_webhook()
        logger.info("Webhook initialization completed")
    except Exception as e:
        logger.error(f"Error initializing webhook: {e}")

def main():
    """
    Main function to start the bot based on the selected mode
    """
    logger.info(f"Starting bot in {BOT_MODE} mode")
    
    if BOT_MODE == "webhook":
        # When using gunicorn, the app is started by gunicorn
        logger.info("Webhook mode - app will be started by gunicorn")
        pass
    else:
        # Start bot in polling mode
        logger.info("Starting bot in polling mode")
        bot = initialize_bot()
        start_polling(bot)

if __name__ == "__main__":
    main()
