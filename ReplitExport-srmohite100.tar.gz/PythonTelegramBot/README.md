# Telegram Bot on Replit

This repository contains a simple Telegram bot implementation using the `pytelegrambotapi` library, deployed on Replit. It supports both polling and webhook methods for receiving updates from Telegram.

## Features

- Ready-to-use bot environment on Replit
- Support for both polling and webhook modes
- Keep-alive mechanism to prevent Replit from sleeping
- Simple web dashboard to monitor the bot status
- Easy configuration using environment variables

## Setup Instructions

### 1. Create a Bot with BotFather

1. Open Telegram and search for [@BotFather](https://t.me/BotFather)
2. Send `/newbot` and follow the instructions to create a new bot
3. Copy the API token provided by BotFather

### 2. Configure Environment Variables

Create a `.env` file with the following variables:

