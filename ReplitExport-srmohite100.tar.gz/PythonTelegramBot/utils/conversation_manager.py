import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# In-memory storage for conversation history
# Format: {user_id: {"last_active": timestamp, "messages": [list of message dicts]}}
user_conversations = {}

# Maximum number of past messages to keep per user
MAX_CONTEXT_LENGTH = 10

# Time window for conversation context (in minutes)
CONVERSATION_TIMEOUT = 30

def add_message(user_id, role, content):
    """
    Add a message to the user's conversation history
    
    Args:
        user_id (int): Telegram user ID
        role (str): Message role ('user' or 'assistant')
        content (str): Message content
    """
    # Initialize user conversation if not exists
    if user_id not in user_conversations:
        user_conversations[user_id] = {
            "last_active": datetime.now(),
            "messages": []
        }
    
    # Update last active timestamp
    user_conversations[user_id]["last_active"] = datetime.now()
    
    # Add message to history
    user_conversations[user_id]["messages"].append({
        "role": role,
        "content": content
    })
    
    # Trim conversation if too long
    if len(user_conversations[user_id]["messages"]) > MAX_CONTEXT_LENGTH:
        user_conversations[user_id]["messages"] = user_conversations[user_id]["messages"][-MAX_CONTEXT_LENGTH:]

def get_conversation_context(user_id):
    """
    Get the conversation context for a user
    
    Args:
        user_id (int): Telegram user ID
        
    Returns:
        list: List of message dicts or [] if no context or expired
    """
    # Check if user has conversation history
    if user_id not in user_conversations:
        return []
    
    # Check if conversation is expired
    last_active = user_conversations[user_id]["last_active"]
    if datetime.now() - last_active > timedelta(minutes=CONVERSATION_TIMEOUT):
        # Clear expired conversation
        user_conversations[user_id]["messages"] = []
        return []
    
    # Return conversation context
    return user_conversations[user_id]["messages"]

def clear_conversation(user_id):
    """
    Clear a user's conversation history
    
    Args:
        user_id (int): Telegram user ID
    """
    if user_id in user_conversations:
        user_conversations[user_id]["messages"] = []
        logger.info(f"Cleared conversation history for user {user_id}")

def get_active_users_count():
    """
    Get the count of users with active conversations
    
    Returns:
        int: Number of active users
    """
    # Count users with activity in the last CONVERSATION_TIMEOUT minutes
    active_threshold = datetime.now() - timedelta(minutes=CONVERSATION_TIMEOUT)
    active_count = sum(1 for user_data in user_conversations.values() 
                      if user_data["last_active"] > active_threshold)
    return active_count