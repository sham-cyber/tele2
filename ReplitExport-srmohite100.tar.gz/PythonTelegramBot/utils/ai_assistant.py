import os
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

# Initialize OpenAI client
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def get_ai_response(user_message, user_id=None, context=None):
    """
    Get a response from the OpenAI API
    
    Args:
        user_message (str): The message from the user
        user_id (str, optional): User identifier for conversation tracking
        context (list, optional): Previous conversation context
        
    Returns:
        str: The AI-generated response
    """
    try:
        # Build the conversation history
        messages = []
        
        # Add system message with bot personality
        messages.append({
            "role": "system", 
            "content": "You are a helpful AI assistant in a Telegram bot. " +
                      "Provide concise, friendly, and helpful responses. " +
                      "If you don't know the answer, be honest about it."
        })
        
        # Add context if provided
        if context:
            messages.extend(context)
            
        # Add the user's new message
        messages.append({"role": "user", "content": user_message})
        
        # Call the OpenAI API
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            max_tokens=500,
            temperature=0.7,
        )
        
        # Extract the response text
        ai_response = response.choices[0].message.content
        
        return ai_response
    
    except Exception as e:
        logger.error(f"Error getting AI response: {e}")
        return "I'm having trouble connecting to my AI brain right now. Please try again later."

def generate_image_from_text(prompt):
    """
    Generate an image from text using DALL-E
    
    Args:
        prompt (str): Text description for image generation
        
    Returns:
        str: URL of the generated image, or None if there was an error
    """
    try:
        # Call the OpenAI DALL-E API
        response = client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            n=1,
            size="1024x1024",
        )
        
        # Extract the image URL
        image_url = response.data[0].url
        
        return image_url
    
    except Exception as e:
        logger.error(f"Error generating image: {e}")
        return None