import os
import datetime
import logging
import shutil
import sqlite3
import dropbox
from pathlib import Path
from dropbox.exceptions import AuthError

logger = logging.getLogger(__name__)

# Constants
BACKUP_DIR = "backups"
DEFAULT_DB_FILE = "bot_database.db"

def create_local_backup(db_path=None):
    """
    Create a local backup of the database
    
    Args:
        db_path (str, optional): Path to the database file. Default is the SQLite database.
    
    Returns:
        str: Path to the backup file, or None if failed
    """
    try:
        # Determine database path
        if db_path is None:
            # Default to SQLite database
            db_path = DEFAULT_DB_FILE
            
        # Ensure the database file exists
        if not os.path.exists(db_path):
            logger.error(f"Database file not found: {db_path}")
            return None
            
        # Create backup directory if it doesn't exist
        if not os.path.exists(BACKUP_DIR):
            os.makedirs(BACKUP_DIR)
            
        # Generate backup filename with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"bot_db_backup_{timestamp}.db"
        backup_path = os.path.join(BACKUP_DIR, backup_filename)
        
        # For SQLite, create a copy of the database file
        if db_path.endswith('.db'):
            # Copy the file
            shutil.copy2(db_path, backup_path)
            logger.info(f"SQLite database backup created at {backup_path}")
            return backup_path
        else:
            # For PostgreSQL or other database types, implement other backup methods
            logger.error("Only SQLite backup is supported in this version")
            return None
            
    except Exception as e:
        logger.error(f"Error creating database backup: {e}")
        return None

def upload_to_dropbox(file_path, access_token):
    """
    Upload a file to Dropbox
    
    Args:
        file_path (str): Path to the file to upload
        access_token (str): Dropbox access token
        
    Returns:
        str: Shared URL of the uploaded file, or None if failed
    """
    try:
        # Validate inputs
        if not os.path.exists(file_path):
            logger.error(f"File not found: {file_path}")
            return None
            
        if not access_token:
            logger.error("No Dropbox access token provided")
            return None
            
        # Initialize Dropbox client
        dbx = dropbox.Dropbox(access_token)
        
        # Verify authentication
        try:
            dbx.users_get_current_account()
        except AuthError:
            logger.error("Invalid Dropbox access token")
            return None
            
        # Open the file and upload it
        file_name = os.path.basename(file_path)
        with open(file_path, 'rb') as f:
            logger.info(f"Uploading {file_path} to Dropbox...")
            
            # Upload the file
            dropbox_path = f"/telegrambot_backups/{file_name}"
            dbx.files_upload(f.read(), dropbox_path, mode=dropbox.files.WriteMode.overwrite)
            
            # Create a shared link
            shared_link = dbx.sharing_create_shared_link_with_settings(dropbox_path)
            logger.info(f"File uploaded to Dropbox: {shared_link.url}")
            
            return shared_link.url
            
    except Exception as e:
        logger.error(f"Error uploading to Dropbox: {e}")
        return None

def backup_database_to_dropbox(access_token, db_path=None):
    """
    Create a database backup and upload it to Dropbox
    
    Args:
        access_token (str): Dropbox access token
        db_path (str, optional): Path to the database file
        
    Returns:
        dict: Result with status and URL
    """
    result = {
        "success": False,
        "local_backup": None,
        "dropbox_url": None,
        "error": None
    }
    
    try:
        # Create local backup
        backup_path = create_local_backup(db_path)
        result["local_backup"] = backup_path
        
        if not backup_path:
            result["error"] = "Failed to create local backup"
            return result
            
        # Upload to Dropbox
        shared_url = upload_to_dropbox(backup_path, access_token)
        result["dropbox_url"] = shared_url
        
        if not shared_url:
            result["error"] = "Failed to upload to Dropbox"
            return result
            
        result["success"] = True
        return result
        
    except Exception as e:
        logger.error(f"Error backing up database: {e}")
        result["error"] = str(e)
        return result