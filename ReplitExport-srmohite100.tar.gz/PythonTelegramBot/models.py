import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

class User(Base):
    """
    Model for Telegram users who interact with the bot
    """
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False)
    username = Column(String(32), nullable=True)
    first_name = Column(String(64), nullable=True)
    last_name = Column(String(64), nullable=True)
    language_code = Column(String(8), nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_interaction = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    messages = relationship("Message", back_populates="user")
    
    def __repr__(self):
        return f"<User(telegram_id={self.telegram_id}, username={self.username})>"

class Message(Base):
    """
    Model for storing messages sent to or received from users
    """
    __tablename__ = 'messages'
    
    id = Column(Integer, primary_key=True)
    telegram_message_id = Column(Integer, nullable=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    chat_id = Column(Integer, nullable=False)
    message_text = Column(Text, nullable=True)
    is_from_user = Column(Boolean, default=True)  # True if from user, False if from bot
    is_from_bot = Column(Boolean, default=False)  # True if from bot, False if from user
    is_command = Column(Boolean, default=False)  # True if message is a command
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="messages")
    
    def __repr__(self):
        return f"<Message(id={self.id}, from_user={self.is_from_user})>"

class BotConfig(Base):
    """
    Model for storing bot configuration settings
    """
    __tablename__ = 'bot_configs'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(128), unique=True, nullable=False)
    value = Column(Text, nullable=True)
    description = Column(Text, nullable=True)
    
    def __repr__(self):
        return f"<BotConfig(name={self.name})>"