import os
import logging
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

# Print environment variables for debugging (without showing the whole token)
bot_token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
token_preview = bot_token[:6] + "..." if bot_token else "Not set"

logger.info(f"Bot Token: {token_preview}")
logger.info(f"Bot Mode: {os.environ.get('BOT_MODE', 'Not set')}")
logger.info(f"Webhook URL: {os.environ.get('WEBHOOK_URL', 'Not set')}")

# Export variables as required
def get_env():
    """Return the environment variables"""
    return {
        "TELEGRAM_BOT_TOKEN": os.environ.get("TELEGRAM_BOT_TOKEN", ""),
        "BOT_MODE": os.environ.get("BOT_MODE", "polling"),
        "WEBHOOK_URL": os.environ.get("WEBHOOK_URL", ""),
        "SESSION_SECRET": os.environ.get("SESSION_SECRET", "default_secret")
    }